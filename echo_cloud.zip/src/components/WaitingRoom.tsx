// src/components/WaitingRoom.tsx
import React from 'react';

const WaitingRoom: React.FC = () => {
  return <p>Waiting for the presentation to begin...</p>;
};

export default WaitingRoom;
