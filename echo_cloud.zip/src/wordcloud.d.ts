// src/wordcloud.d.ts
declare module 'wordcloud';
