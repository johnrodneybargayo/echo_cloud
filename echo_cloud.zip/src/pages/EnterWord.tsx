import WordInput from '../components/WordInput';

const EnterWord = () => (
  <div>
    <WordInput />
  </div>
);

export default EnterWord;
