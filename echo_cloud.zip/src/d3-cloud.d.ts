// src/d3-cloud.d.ts
declare module 'd3-cloud' {
    const cloud: any;
    export default cloud;
  }
  