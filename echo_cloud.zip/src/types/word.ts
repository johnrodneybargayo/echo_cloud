// src/types/word.ts
export interface Word {
    word: string;
    count: number;
  }
  